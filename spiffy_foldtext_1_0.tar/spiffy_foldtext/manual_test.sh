#!/bin/sh

rm -rf ~/.vim/bundle/spiffy_foldtext/
cp -r ~/local_code/spiffy_foldtext/ ~/.vim/bundle/
gvim ~/dot_files/vimrc

return 0
